CREATE TABLE clientes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(255),
  sobrenome VARCHAR(255),
  email VARCHAR(255),
  idade INT
);
