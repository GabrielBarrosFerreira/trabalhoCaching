# Desafio - API RESTful com Express, MySQL e Cache

Este projeto consiste em uma API RESTful construída com Node.js e Express que realiza operações CRUD nas entidades "clientes" e "produtos", utilizando banco de dados MySQL e cache com `node-cache`.
